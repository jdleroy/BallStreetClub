<head>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- Index Stylesheet -->
    <link rel="stylesheet" href="index.css">

    <!-- Index JavaScript -->
    <script src="index.js"></script>

    <!-- Roboto Font -->
    <style>@import url('https://fonts.googleapis.com/css?family=Roboto');</style>

    <!-- Google Charts -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', {packages: ['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            // Define the chart to be drawn.
            var data = google.visualization.arrayToDataTable([
                ['Year', 'Sales', 'Expenses'],
                ['2004', 1000, 400],
                ['2005', 1170, 460],
                ['2006', 660, 1120],
                ['2007', 1030, 540]
            ]);

            var options = {
                title: 'Company Performance',
                curveType: 'function',
                legend: {position: 'bottom'}
            };

            var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

            chart.draw(data, options);
        }
    </script>
</head>

<?php
$team = "<div class='team'>
                    <div class='team-list-logo-padding'>
                        <div class='team-list-logo'>

                        </div>
                    </div>
                    <div class='team-list-info'>
                        <div class='team-list-info-left'>
                            <div class='team-list-name'>
                                Alabama
                            </div>
                            <div class='team-list-stockname'>
                                (ALA)
                            </div>
                        </div>
                        <div class='team-list-info-right'>
                            <div class='team-list-price'>
                                12.51 <span class='glyphicon glyphicon-triangle-top'></span>
                            </div>
                            <div class='team-list-trending'>
                            
                            </div>
                        </div>
                    </div>
                </div>";
?>

<body>
<div class="container-fluid page-fluid">
    <div class="container page">
        <div class="col-sm-8">
            <div class="team-stock">
                <div class="team-stock-graph-frame">
                    <!-- Google Charts -->
                    <div id="curve_chart" style="width: 799px; height: 400px;"></div>
                </div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="team-sort">
                Sort
            </div>
            <div class="team-list">
                <?php
                for ($i = 0; $i < 20; $i++) {
                    echo $team;
                }
                ?>
            </div>
        </div>
    </div>
</div>
</body>